<?php
class Gerenciar_ImportarController extends Zend_Controller_Action
{

    public function init()
    {
        
    }

    public function indexAction()
    {
    }
}