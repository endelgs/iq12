<?php

class PartialsController extends Zend_Controller_Action
{

    public function init()
    {
   	}

    public function indexAction()
    {
        // action body
    }

    public function posgraduacaoheaderAction()
    {

    }
    
    public function pessoaheaderAction()
    {
		
    }

}

