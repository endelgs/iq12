<?php
class Application_Models_Trancamento extends Zend_Db_Table_Abstract
{
    protected $_name = 'trancamento';
        

    
    
}
?>