<?php

require_once(APPLICATION_PATH . '/../library/relatorios/GridPdf.php');
require_once(APPLICATION_PATH . '/../library/componentes/Mascara.php');
require_once(APPLICATION_PATH . '/models/ListaRelatorioPDF.php');
require_once(APPLICATION_PATH . '/models/Orientadores.php');
require_once(APPLICATION_PATH . '/models/Alunos.php');
require_once(APPLICATION_PATH . '/models/General.php');

class Dashboard_IndexController extends Zend_Controller_Action {

    public function init() {
        /* Initialize action controller here */
    }

    public function indexAction() {

        $alunos = new Application_Models_Alunos();
        $GridPDF = new GridPdf();


        $array = array(
            'ativos' => 'sim',
            'periodo' => 'nao',
            'data' => date('Y-m-d'),
            'curso' => 'todos',
            'params' => ', pes.nome AS nome_pessoa, pes.cpf , ingr.ra',
            'sql' => 'LEFT JOIN pessoas pes on pes.id_pessoa = pg.id_pessoa
		      LEFT JOIN ingressos ingr ON ingr.id_pos_graduacao = pg.id_pos_graduacao',
                //	'and'		=> 'AND ps.nome LIKE "%'.$nome.'%"'
        );



        $lista = $alunos->listaalunos($array);

        foreach ($lista as $index => $arr) {
            $link = $this->view->url(array('module' => 'pessoas', 'controller' => 'geral', 'action' => 'index', 'id_pessoa' => $arr['id_pessoa']));

            $dadoLink = '<a href="' . $link . '">Ver</a>';
            $lista[$index]['link'] = $dadoLink;
            $lista[$index]['nome'] = $arr['nome_pessoa'];
            
            //problemas no banco, não há como mexer no do iq, por se tratar de excecoes
            if("Abdul Majeed Khan"==$arr['nome_pessoa'])
            	$arr['ra']="089427";
            if("Marcus Vinicius Cangussu Cardoso"==$arr['nome_pessoa'])
            	$arr['ra']="080359";
            	
            $dadoLinkRA = '<a href="' . $link . '">' . $arr['ra'] . '</a>';
            $lista[$index]['ra'] = $arr['ra'];
        }
        $headers = array(
            'ra' => 'RA',
            'nome' => 'Nome Aluno',
            'curso' => 'Curso',
            'link' => ' ',
        );

        //var_dump($lista);
        $this->view->flex1 = $GridPDF->flexGridJS($lista, $headers, 750, 210);

        //-----------------------------------------------------//

        $tabela = new Application_Models_ListaRelatiorPDF();
        $tabela->table('v_relatorio_pendente');
        $tabela->primary('ra');
        $lista = $tabela->CRUDread();

        foreach ($lista as $index => $arr) {
            $link = $this->view->url(array('module' => 'pessoas', 'controller' => 'geral', 'action' => 'index', 'id_pessoa' => $arr['id_pessoa']));

            $dadoLink = '<a href="' . $link . '">Ver</a>';
            $lista[$index]['link'] = $dadoLink;
            $lista[$index]['nome'] = $arr['nome'];
            $dadoLinkRA = '<a href="' . $link . '">' . $arr['ra'] . '</a>';
            $lista[$index]['linkra'] = $arr['ra'];
        }

            $headers = array(
            'ra' => 'RA',
            'nome' => 'Nome Aluno',
            'tipo_curso' => 'Curso',
            'link' => ' ',
        );
        //var_dump($lista);
        $this->view->flex2 = $GridPDF->flexGridJS($lista, $headers, 750, 210);

        //-----------------------------------------------------//
        $mesAnt = date("Y-m-d h:i:s");
        $mesProx = date("Y-m-d h:i:s", (mktime(0, 0, 0, date("m") + 6, date("d"), date("Y"))));

        $tabela = new Application_Models_ListaRelatiorPDF();
        $tabela->table('v_ingresso_reingresso');
        $tabela->primary('RA');

        $where = "(`data_integralizacao_ingresso`>='$mesAnt' AND  `data_integralizacao_ingresso`<='$mesProx') ";
        $where.=" OR (`data_integralizacao_reingresso`>='$mesAnt' AND  `data_integralizacao_reingresso`<='$mesProx')  ";
        $tabela->where = $where;

        $lista = $tabela->CRUDread();
		
        foreach ($lista as $index => $arr) {
            $link = $this->view->url(array('module' => 'pessoas', 'controller' => 'geral', 'action' => 'index', 'id_pessoa' => $arr['id_pessoa']));

            $dadoLink = '<a href="' . $link . '">Ver</a>';
            $lista[$index]['link'] = $dadoLink;
            $lista[$index]['nome'] = $arr['nome'];
            $dadoLinkRA = '<a href="' . $link . '">' . $arr['RA'] . '</a>';
            $lista[$index]['ra'] = $arr['RA'];
        }

        $headers = array(
            'ra' => 'RA',
            'nome' => 'Nome Aluno',
            'tipo_curso' => 'Curso',
             'link' => ' ',
        );

        //var_dump($lista);
        $this->view->flex3 = $GridPDF->flexGridJS($lista, $headers, 750, 210);
    }

}

